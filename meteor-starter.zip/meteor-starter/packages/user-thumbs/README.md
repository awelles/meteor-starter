meteor-user-helpers
===================

Adds helpers for displaying profile pictures and more.
